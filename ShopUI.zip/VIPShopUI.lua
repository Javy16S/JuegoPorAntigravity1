-- VIPShopUI.lua
-- ScreenGui structure for Roblox VIP Shop
-- Place this in StarterGui

local ShopUI = Instance.new("ScreenGui")
ShopUI.Name = "VIPShopUI"
ShopUI.ResetOnSpawn = false
ShopUI.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
ShopUI.IgnoreGuiInset = false
ShopUI.DisplayOrder = 100

-- Main Container
local MainFrame = Instance.new("Frame")
MainFrame.Name = "MainFrame"
MainFrame.Size = UDim2.new(0, 1200, 0, 700)
MainFrame.Position = UDim2.new(0.5, 0, 0.5, 0)
MainFrame.AnchorPoint = Vector2.new(0.5, 0.5)
MainFrame.BackgroundColor3 = Color3.fromRGB(25, 15, 45)
MainFrame.BorderSizePixel = 0
MainFrame.Parent = ShopUI
MainFrame.Visible = false

-- Add rounded corners
local MainCorner = Instance.new("UICorner")
MainCorner.CornerRadius = UDim.new(0, 20)
MainCorner.Parent = MainFrame

-- Add gradient background
local Gradient = Instance.new("UIGradient")
Gradient.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(60, 20, 100)),
    ColorSequenceKeypoint.new(0.5, Color3.fromRGB(80, 30, 120)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(100, 40, 80))
})
Gradient.Rotation = 45
Gradient.Parent = MainFrame

-- Header Background
local Header = Instance.new("Frame")
Header.Name = "Header"
Header.Size = UDim2.new(1, -40, 0, 100)
Header.Position = UDim2.new(0, 20, 0, 20)
Header.BackgroundColor3 = Color3.fromRGB(255, 150, 50)
Header.BorderSizePixel = 0
Header.Parent = MainFrame

local HeaderCorner = Instance.new("UICorner")
HeaderCorner.CornerRadius = UDim.new(0, 15)
HeaderCorner.Parent = Header

local HeaderGradient = Instance.new("UIGradient")
HeaderGradient.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 200, 50)),
    ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 150, 50)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 100, 50))
})
HeaderGradient.Rotation = 90
HeaderGradient.Parent = Header

-- Header Stroke (Border)
local HeaderStroke = Instance.new("UIStroke")
HeaderStroke.Color = Color3.fromRGB(255, 255, 255)
HeaderStroke.Thickness = 5
HeaderStroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
HeaderStroke.Parent = Header

-- Title Label
local TitleLabel = Instance.new("TextLabel")
TitleLabel.Name = "TitleLabel"
TitleLabel.Size = UDim2.new(0, 300, 1, 0)
TitleLabel.Position = UDim2.new(0, 100, 0, 0)
TitleLabel.BackgroundTransparency = 1
TitleLabel.Text = "TIENDA"
TitleLabel.Font = Enum.Font.FredokaOne
TitleLabel.TextSize = 60
TitleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
TitleLabel.TextStrokeTransparency = 0.5
TitleLabel.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
TitleLabel.TextXAlignment = Enum.TextXAlignment.Left
TitleLabel.Parent = Header

-- Subtitle
local SubtitleLabel = Instance.new("TextLabel")
SubtitleLabel.Name = "SubtitleLabel"
SubtitleLabel.Size = UDim2.new(0, 300, 0, 30)
SubtitleLabel.Position = UDim2.new(0, 100, 1, -35)
SubtitleLabel.BackgroundTransparency = 1
SubtitleLabel.Text = "¡Mejores Ofertas VIP!"
SubtitleLabel.Font = Enum.Font.GothamBold
SubtitleLabel.TextSize = 20
SubtitleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
SubtitleLabel.TextXAlignment = Enum.TextXAlignment.Left
SubtitleLabel.Parent = Header

-- Icon Container (shopping cart icon area)
local IconFrame = Instance.new("Frame")
IconFrame.Name = "IconFrame"
IconFrame.Size = UDim2.new(0, 80, 0, 80)
IconFrame.Position = UDim2.new(0, 10, 0.5, 0)
IconFrame.AnchorPoint = Vector2.new(0, 0.5)
IconFrame.BackgroundColor3 = Color3.fromRGB(220, 50, 100)
IconFrame.BorderSizePixel = 0
IconFrame.Rotation = -5
IconFrame.Parent = Header

local IconCorner = Instance.new("UICorner")
IconCorner.CornerRadius = UDim.new(0, 15)
IconCorner.Parent = IconFrame

local IconGradient = Instance.new("UIGradient")
IconGradient.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(250, 80, 120)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(220, 50, 100))
})
IconGradient.Rotation = 135
IconGradient.Parent = IconFrame

-- Cart Counter Button (top right)
local CartButton = Instance.new("TextButton")
CartButton.Name = "CartButton"
CartButton.Size = UDim2.new(0, 120, 0, 60)
CartButton.Position = UDim2.new(1, -130, 0.5, 0)
CartButton.AnchorPoint = Vector2.new(0, 0.5)
CartButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
CartButton.BackgroundTransparency = 0.7
CartButton.BorderSizePixel = 0
CartButton.Text = "🛒 0"
CartButton.Font = Enum.Font.FredokaOne
CartButton.TextSize = 30
CartButton.TextColor3 = Color3.fromRGB(255, 255, 255)
CartButton.Parent = Header

local CartCorner = Instance.new("UICorner")
CartCorner.CornerRadius = UDim.new(0, 12)
CartCorner.Parent = CartButton

local CartStroke = Instance.new("UIStroke")
CartStroke.Color = Color3.fromRGB(255, 255, 255)
CartStroke.Thickness = 4
CartStroke.Transparency = 0.4
CartStroke.Parent = CartButton

-- Close Button
local CloseButton = Instance.new("TextButton")
CloseButton.Name = "CloseButton"
CloseButton.Size = UDim2.new(0, 50, 0, 50)
CloseButton.Position = UDim2.new(1, 10, 0, -10)
CloseButton.AnchorPoint = Vector2.new(0.5, 0.5)
CloseButton.BackgroundColor3 = Color3.fromRGB(220, 50, 50)
CloseButton.BorderSizePixel = 0
CloseButton.Text = "✕"
CloseButton.Font = Enum.Font.FredokaOne
CloseButton.TextSize = 30
CloseButton.TextColor3 = Color3.fromRGB(255, 255, 255)
CloseButton.Parent = MainFrame

local CloseCorner = Instance.new("UICorner")
CloseCorner.CornerRadius = UDim.new(0, 10)
CloseCorner.Parent = CloseButton

local CloseStroke = Instance.new("UIStroke")
CloseStroke.Color = Color3.fromRGB(255, 255, 255)
CloseStroke.Thickness = 3
CloseStroke.Parent = CloseButton

-- Tab Buttons Container
local TabsContainer = Instance.new("Frame")
TabsContainer.Name = "TabsContainer"
TabsContainer.Size = UDim2.new(1, -40, 0, 70)
TabsContainer.Position = UDim2.new(0, 20, 0, 140)
TabsContainer.BackgroundTransparency = 1
TabsContainer.Parent = MainFrame

-- VIP Tab Button
local VIPTabButton = Instance.new("TextButton")
VIPTabButton.Name = "VIPTabButton"
VIPTabButton.Size = UDim2.new(0.48, 0, 1, 0)
VIPTabButton.Position = UDim2.new(0, 0, 0, 0)
VIPTabButton.BackgroundColor3 = Color3.fromRGB(50, 200, 100)
VIPTabButton.BorderSizePixel = 0
VIPTabButton.Text = "🎁 PACKS VIP"
VIPTabButton.Font = Enum.Font.FredokaOne
VIPTabButton.TextSize = 28
VIPTabButton.TextColor3 = Color3.fromRGB(255, 255, 255)
VIPTabButton.Parent = TabsContainer

local VIPTabCorner = Instance.new("UICorner")
VIPTabCorner.CornerRadius = UDim.new(0, 15)
VIPTabCorner.Parent = VIPTabButton

local VIPTabStroke = Instance.new("UIStroke")
VIPTabStroke.Color = Color3.fromRGB(255, 255, 255)
VIPTabStroke.Thickness = 5
VIPTabStroke.Parent = VIPTabButton

local VIPTabGradient = Instance.new("UIGradient")
VIPTabGradient.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(80, 220, 120)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(50, 180, 100))
})
VIPTabGradient.Rotation = 90
VIPTabGradient.Parent = VIPTabButton

-- Cosmetics Tab Button
local CosmeticsTabButton = Instance.new("TextButton")
CosmeticsTabButton.Name = "CosmeticsTabButton"
CosmeticsTabButton.Size = UDim2.new(0.48, 0, 1, 0)
CosmeticsTabButton.Position = UDim2.new(0.52, 0, 0, 0)
CosmeticsTabButton.BackgroundColor3 = Color3.fromRGB(80, 80, 120)
CosmeticsTabButton.BackgroundTransparency = 0.5
CosmeticsTabButton.BorderSizePixel = 0
CosmeticsTabButton.Text = "✨ COSMÉTICOS"
CosmeticsTabButton.Font = Enum.Font.FredokaOne
CosmeticsTabButton.TextSize = 28
CosmeticsTabButton.TextColor3 = Color3.fromRGB(200, 200, 220)
CosmeticsTabButton.Parent = TabsContainer

local CosmeticsTabCorner = Instance.new("UICorner")
CosmeticsTabCorner.CornerRadius = UDim.new(0, 15)
CosmeticsTabCorner.Parent = CosmeticsTabButton

local CosmeticsTabStroke = Instance.new("UIStroke")
CosmeticsTabStroke.Color = Color3.fromRGB(255, 255, 255)
CosmeticsTabStroke.Thickness = 5
CosmeticsTabStroke.Transparency = 0.7
CosmeticsTabStroke.Parent = CosmeticsTabButton

-- Content Container (scrolling frame for items)
local ContentFrame = Instance.new("ScrollingFrame")
ContentFrame.Name = "ContentFrame"
ContentFrame.Size = UDim2.new(1, -40, 1, -260)
ContentFrame.Position = UDim2.new(0, 20, 0, 230)
ContentFrame.BackgroundTransparency = 1
ContentFrame.BorderSizePixel = 0
ContentFrame.ScrollBarThickness = 10
ContentFrame.ScrollBarImageColor3 = Color3.fromRGB(255, 150, 255)
ContentFrame.CanvasSize = UDim2.new(0, 0, 0, 0)
ContentFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y
ContentFrame.Parent = MainFrame

-- Grid Layout for Items
local GridLayout = Instance.new("UIGridLayout")
GridLayout.CellSize = UDim2.new(0, 360, 0, 280)
GridLayout.CellPadding = UDim2.new(0, 20, 0, 20)
GridLayout.SortOrder = Enum.SortOrder.LayoutOrder
GridLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
GridLayout.Parent = ContentFrame

return ShopUI
