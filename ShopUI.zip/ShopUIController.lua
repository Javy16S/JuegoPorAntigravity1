-- ShopUIController.lua
-- Client-side controller for VIP Shop UI
-- Place this in StarterPlayer/StarterPlayerScripts/

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local Player = Players.LocalPlayer
local PlayerGui = Player:WaitForChild("PlayerGui")

-- Wait for modules
local ShopData = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("ShopData"))

-- Wait for RemoteEvents
local Events = ReplicatedStorage:WaitForChild("Events")
local PurchaseItemEvent = Events:WaitForChild("PurchaseItem")
local OpenShopEvent = Events:WaitForChild("OpenShop")

-- Wait for UI
local ShopUI = PlayerGui:WaitForChild("VIPShopUI")
local MainFrame = ShopUI:WaitForChild("MainFrame")
local Header = MainFrame:WaitForChild("Header")
local CartButton = Header:WaitForChild("CartButton")
local CloseButton = MainFrame:WaitForChild("CloseButton")
local TabsContainer = MainFrame:WaitForChild("TabsContainer")
local VIPTabButton = TabsContainer:WaitForChild("VIPTabButton")
local CosmeticsTabButton = TabsContainer:WaitForChild("CosmeticsTabButton")
local ContentFrame = MainFrame:WaitForChild("ContentFrame")

-- STATE
local currentTab = "VIP"
local cart = {}
local isShopOpen = false

-- FUNCTIONS: UI Animation
local function tweenIn(frame)
	frame.Visible = true
	frame.Size = UDim2.new(0, 0, 0, 0)
	frame.Position = UDim2.new(0.5, 0, 0.5, 0)
	
	local tween = TweenService:Create(frame, TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
		Size = UDim2.new(0, 1200, 0, 700),
		Position = UDim2.new(0.5, 0, 0.5, 0)
	})
	tween:Play()
end

local function tweenOut(frame, callback)
	local tween = TweenService:Create(frame, TweenInfo.new(0.2, Enum.EasingStyle.Back, Enum.EasingDirection.In), {
		Size = UDim2.new(0, 0, 0, 0)
	})
	tween:Play()
	tween.Completed:Connect(function()
		frame.Visible = false
		if callback then
			callback()
		end
	end)
end

local function createGradient(parent, colorGradient)
	local gradient = Instance.new("UIGradient")
	
	local keypoints = {}
	if colorGradient.Middle then
		keypoints = {
			ColorSequenceKeypoint.new(0, colorGradient.Start),
			ColorSequenceKeypoint.new(0.5, colorGradient.Middle),
			ColorSequenceKeypoint.new(1, colorGradient.End)
		}
	else
		keypoints = {
			ColorSequenceKeypoint.new(0, colorGradient.Start),
			ColorSequenceKeypoint.new(1, colorGradient.End)
		}
	end
	
	gradient.Color = ColorSequence.new(keypoints)
	gradient.Rotation = 90
	gradient.Parent = parent
	return gradient
end

-- FUNCTIONS: VIP Item Creation
local function createVIPPackageCard(packageData)
	local Card = Instance.new("Frame")
	Card.Name = "VIPCard_" .. packageData.ID
	Card.BackgroundColor3 = Color3.fromRGB(40, 20, 60)
	Card.BorderSizePixel = 0
	Card.LayoutOrder = packageData.SortOrder
	
	local CardCorner = Instance.new("UICorner")
	CardCorner.CornerRadius = UDim.new(0, 20)
	CardCorner.Parent = Card
	
	-- Outer border frame
	local BorderFrame = Instance.new("Frame")
	BorderFrame.Name = "BorderFrame"
	BorderFrame.Size = UDim2.new(1, 8, 1, 8)
	BorderFrame.Position = UDim2.new(0.5, 0, 0.5, 0)
	BorderFrame.AnchorPoint = Vector2.new(0.5, 0.5)
	BorderFrame.BackgroundColor3 = packageData.ColorGradient.Start
	BorderFrame.BorderSizePixel = 0
	BorderFrame.ZIndex = 0
	BorderFrame.Parent = Card
	
	local BorderCorner = Instance.new("UICorner")
	BorderCorner.CornerRadius = UDim.new(0, 22)
	BorderCorner.Parent = BorderFrame
	
	createGradient(BorderFrame, packageData.ColorGradient)
	
	-- Glow effect
	local Glow = Instance.new("ImageLabel")
	Glow.Name = "Glow"
	Glow.Size = UDim2.new(1, 40, 1, 40)
	Glow.Position = UDim2.new(0.5, 0, 0.5, 0)
	Glow.AnchorPoint = Vector2.new(0.5, 0.5)
	Glow.BackgroundTransparency = 1
	Glow.Image = "rbxasset://textures/ui/Glow.png"
	Glow.ImageColor3 = packageData.ColorGradient.Start
	Glow.ImageTransparency = 0.5
	Glow.ZIndex = 0
	Glow.Parent = Card
	
	-- Popular badge
	if packageData.Popular then
		local PopularBadge = Instance.new("Frame")
		PopularBadge.Name = "PopularBadge"
		PopularBadge.Size = UDim2.new(0, 180, 0, 40)
		PopularBadge.Position = UDim2.new(0.5, 0, 0, -20)
		PopularBadge.AnchorPoint = Vector2.new(0.5, 0)
		PopularBadge.BackgroundColor3 = Color3.fromRGB(255, 200, 50)
		PopularBadge.BorderSizePixel = 0
		PopularBadge.ZIndex = 10
		PopularBadge.Parent = Card
		
		local BadgeCorner = Instance.new("UICorner")
		BadgeCorner.CornerRadius = UDim.new(0, 20)
		BadgeCorner.Parent = PopularBadge
		
		local BadgeStroke = Instance.new("UIStroke")
		BadgeStroke.Color = Color3.fromRGB(255, 255, 255)
		BadgeStroke.Thickness = 4
		BadgeStroke.Parent = PopularBadge
		
		local BadgeLabel = Instance.new("TextLabel")
		BadgeLabel.Size = UDim2.new(1, 0, 1, 0)
		BadgeLabel.BackgroundTransparency = 1
		BadgeLabel.Text = "⭐ MÁS POPULAR ⭐"
		BadgeLabel.Font = Enum.Font.FredokaOne
		BadgeLabel.TextSize = 16
		BadgeLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
		BadgeLabel.TextStrokeTransparency = 0.5
		BadgeLabel.Parent = PopularBadge
	end
	
	-- Icon
	local IconLabel = Instance.new("TextLabel")
	IconLabel.Name = "IconLabel"
	IconLabel.Size = UDim2.new(0, 80, 0, 80)
	IconLabel.Position = UDim2.new(0.5, 0, 0, 30)
	IconLabel.AnchorPoint = Vector2.new(0.5, 0)
	IconLabel.BackgroundTransparency = 1
	IconLabel.Text = packageData.Icon
	IconLabel.Font = Enum.Font.FredokaOne
	IconLabel.TextSize = 60
	IconLabel.Parent = Card
	
	-- Package Name
	local NameLabel = Instance.new("TextLabel")
	NameLabel.Name = "NameLabel"
	NameLabel.Size = UDim2.new(1, -20, 0, 35)
	NameLabel.Position = UDim2.new(0, 10, 0, 120)
	NameLabel.BackgroundTransparency = 1
	NameLabel.Text = packageData.Name
	NameLabel.Font = Enum.Font.FredokaOne
	NameLabel.TextSize = 28
	NameLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	NameLabel.TextStrokeTransparency = 0.7
	NameLabel.Parent = Card
	
	-- Bonus Badge
	local BonusFrame = Instance.new("Frame")
	BonusFrame.Name = "BonusFrame"
	BonusFrame.Size = UDim2.new(0, 180, 0, 40)
	BonusFrame.Position = UDim2.new(0.5, 0, 0, 160)
	BonusFrame.AnchorPoint = Vector2.new(0.5, 0)
	BonusFrame.BackgroundColor3 = Color3.fromRGB(50, 200, 100)
	BonusFrame.BorderSizePixel = 0
	BonusFrame.Parent = Card
	
	local BonusCorner = Instance.new("UICorner")
	BonusCorner.CornerRadius = UDim.new(0, 12)
	BonusCorner.Parent = BonusFrame
	
	local BonusStroke = Instance.new("UIStroke")
	BonusStroke.Color = Color3.fromRGB(255, 255, 255)
	BonusStroke.Thickness = 3
	BonusStroke.Transparency = 0.3
	BonusStroke.Parent = BonusFrame
	
	local BonusLabel = Instance.new("TextLabel")
	BonusLabel.Size = UDim2.new(1, 0, 1, 0)
	BonusLabel.BackgroundTransparency = 1
	BonusLabel.Text = "+" .. packageData.BonusTokens .. " GRATIS"
	BonusLabel.Font = Enum.Font.FredokaOne
	BonusLabel.TextSize = 20
	BonusLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	BonusLabel.Parent = BonusFrame
	
	-- Total Tokens Display
	local TotalLabel = Instance.new("TextLabel")
	TotalLabel.Name = "TotalLabel"
	TotalLabel.Size = UDim2.new(1, -20, 0, 40)
	TotalLabel.Position = UDim2.new(0, 10, 0, 210)
	TotalLabel.BackgroundTransparency = 1
	TotalLabel.Text = tostring(packageData.TotalTokens)
	TotalLabel.Font = Enum.Font.FredokaOne
	TotalLabel.TextSize = 50
	TotalLabel.TextColor3 = Color3.fromRGB(255, 220, 100)
	TotalLabel.TextStrokeTransparency = 0
	TotalLabel.TextStrokeColor3 = Color3.fromRGB(200, 150, 0)
	TotalLabel.Parent = Card
	
	-- Buy Button
	local BuyButton = Instance.new("TextButton")
	BuyButton.Name = "BuyButton"
	BuyButton.Size = UDim2.new(1, -30, 0, 50)
	BuyButton.Position = UDim2.new(0.5, 0, 1, -60)
	BuyButton.AnchorPoint = Vector2.new(0.5, 0)
	BuyButton.BackgroundColor3 = Color3.fromRGB(50, 200, 100)
	BuyButton.BorderSizePixel = 0
	BuyButton.Text = "◎" .. packageData.Price
	BuyButton.Font = Enum.Font.FredokaOne
	BuyButton.TextSize = 32
	BuyButton.TextColor3 = Color3.fromRGB(255, 255, 255)
	BuyButton.Parent = Card
	
	local BuyCorner = Instance.new("UICorner")
	BuyCorner.CornerRadius = UDim.new(0, 15)
	BuyCorner.Parent = BuyButton
	
	local BuyStroke = Instance.new("UIStroke")
	BuyStroke.Color = Color3.fromRGB(255, 255, 255)
	BuyStroke.Thickness = 4
	BuyStroke.Transparency = 0.4
	BuyStroke.Parent = BuyButton
	
	local BuyGradient = Instance.new("UIGradient")
	BuyGradient.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, Color3.fromRGB(80, 220, 120)),
		ColorSequenceKeypoint.new(1, Color3.fromRGB(50, 180, 100))
	})
	BuyGradient.Rotation = 90
	BuyGradient.Parent = BuyButton
	
	-- Button hover effect
	BuyButton.MouseEnter:Connect(function()
		TweenService:Create(BuyButton, TweenInfo.new(0.2), {
			Size = UDim2.new(1, -25, 0, 55)
		}):Play()
	end)
	
	BuyButton.MouseLeave:Connect(function()
		TweenService:Create(BuyButton, TweenInfo.new(0.2), {
			Size = UDim2.new(1, -30, 0, 50)
		}):Play()
	end)
	
	BuyButton.MouseButton1Click:Connect(function()
		table.insert(cart, {Type = "VIP", Data = packageData})
		updateCartDisplay()
		PurchaseItemEvent:FireServer("VIP", packageData.ID)
	end)
	
	return Card
end

-- FUNCTIONS: Cosmetic Item Creation
local function createCosmeticCard(itemData)
	local Card = Instance.new("Frame")
	Card.Name = "CosmeticCard_" .. itemData.ID
	Card.BackgroundColor3 = Color3.fromRGB(40, 20, 60)
	Card.BorderSizePixel = 0
	Card.LayoutOrder = itemData.SortOrder
	
	local CardCorner = Instance.new("UICorner")
	CardCorner.CornerRadius = UDim.new(0, 20)
	CardCorner.Parent = Card
	
	-- Border frame with gradient
	local BorderFrame = Instance.new("Frame")
	BorderFrame.Name = "BorderFrame"
	BorderFrame.Size = UDim2.new(1, 8, 1, 8)
	BorderFrame.Position = UDim2.new(0.5, 0, 0.5, 0)
	BorderFrame.AnchorPoint = Vector2.new(0.5, 0.5)
	BorderFrame.BackgroundColor3 = itemData.ColorGradient.Start
	BorderFrame.BorderSizePixel = 0
	BorderFrame.ZIndex = 0
	BorderFrame.Parent = Card
	
	local BorderCorner = Instance.new("UICorner")
	BorderCorner.CornerRadius = UDim.new(0, 22)
	BorderCorner.Parent = BorderFrame
	
	createGradient(BorderFrame, itemData.ColorGradient)
	
	-- Preview Box
	local PreviewBox = Instance.new("Frame")
	PreviewBox.Name = "PreviewBox"
	PreviewBox.Size = UDim2.new(1, -30, 0, 120)
	PreviewBox.Position = UDim2.new(0.5, 0, 0, 15)
	PreviewBox.AnchorPoint = Vector2.new(0.5, 0)
	PreviewBox.BackgroundColor3 = itemData.ColorGradient.Start
	PreviewBox.BorderSizePixel = 0
	PreviewBox.Parent = Card
	
	local PreviewCorner = Instance.new("UICorner")
	PreviewCorner.CornerRadius = UDim.new(0, 15)
	PreviewCorner.Parent = PreviewBox
	
	createGradient(PreviewBox, itemData.ColorGradient)
	
	local PreviewStroke = Instance.new("UIStroke")
	PreviewStroke.Color = Color3.fromRGB(255, 255, 255)
	PreviewStroke.Thickness = 3
	PreviewStroke.Transparency = 0.3
	PreviewStroke.Parent = PreviewBox
	
	-- Icon in preview
	local IconLabel = Instance.new("TextLabel")
	IconLabel.Size = UDim2.new(1, 0, 1, 0)
	IconLabel.BackgroundTransparency = 1
	IconLabel.Text = itemData.Icon
	IconLabel.Font = Enum.Font.FredokaOne
	IconLabel.TextSize = 70
	IconLabel.Parent = PreviewBox
	
	-- Item Name
	local NameLabel = Instance.new("TextLabel")
	NameLabel.Size = UDim2.new(1, -20, 0, 30)
	NameLabel.Position = UDim2.new(0, 10, 0, 145)
	NameLabel.BackgroundTransparency = 1
	NameLabel.Text = itemData.Name
	NameLabel.Font = Enum.Font.FredokaOne
	NameLabel.TextSize = 22
	NameLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	NameLabel.TextStrokeTransparency = 0.7
	NameLabel.Parent = Card
	
	-- Rarity and Chance Container
	local InfoContainer = Instance.new("Frame")
	InfoContainer.Size = UDim2.new(1, -20, 0, 30)
	InfoContainer.Position = UDim2.new(0, 10, 0, 180)
	InfoContainer.BackgroundTransparency = 1
	InfoContainer.Parent = Card
	
	-- Rarity Badge
	local RarityBadge = Instance.new("Frame")
	RarityBadge.Size = UDim2.new(0, 120, 1, 0)
	RarityBadge.Position = UDim2.new(0, 0, 0, 0)
	RarityBadge.BackgroundColor3 = ShopData.RARITY_COLORS[itemData.Rarity]
	RarityBadge.BorderSizePixel = 0
	RarityBadge.Parent = InfoContainer
	
	local RarityCorner = Instance.new("UICorner")
	RarityCorner.CornerRadius = UDim.new(0, 15)
	RarityCorner.Parent = RarityBadge
	
	local RarityStroke = Instance.new("UIStroke")
	RarityStroke.Color = Color3.fromRGB(255, 255, 255)
	RarityStroke.Thickness = 2
	RarityStroke.Transparency = 0.4
	RarityStroke.Parent = RarityBadge
	
	local RarityLabel = Instance.new("TextLabel")
	RarityLabel.Size = UDim2.new(1, 0, 1, 0)
	RarityLabel.BackgroundTransparency = 1
	RarityLabel.Text = itemData.Rarity
	RarityLabel.Font = Enum.Font.GothamBold
	RarityLabel.TextSize = 14
	RarityLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
	RarityLabel.Parent = RarityBadge
	
	-- Drop Chance
	local ChanceLabel = Instance.new("TextLabel")
	ChanceLabel.Size = UDim2.new(0, 100, 1, 0)
	ChanceLabel.Position = UDim2.new(1, -100, 0, 0)
	ChanceLabel.BackgroundTransparency = 1
	ChanceLabel.Text = itemData.DropChance .. "%"
	ChanceLabel.Font = Enum.Font.FredokaOne
	ChanceLabel.TextSize = 20
	ChanceLabel.TextColor3 = Color3.fromRGB(255, 220, 100)
	ChanceLabel.TextXAlignment = Enum.TextXAlignment.Right
	ChanceLabel.Parent = InfoContainer
	
	-- Buy Button
	local BuyButton = Instance.new("TextButton")
	BuyButton.Size = UDim2.new(1, -30, 0, 45)
	BuyButton.Position = UDim2.new(0.5, 0, 1, -55)
	BuyButton.AnchorPoint = Vector2.new(0.5, 0)
	BuyButton.BackgroundColor3 = Color3.fromRGB(255, 180, 50)
	BuyButton.BorderSizePixel = 0
	BuyButton.Text = "◎" .. itemData.Price
	BuyButton.Font = Enum.Font.FredokaOne
	BuyButton.TextSize = 28
	BuyButton.TextColor3 = Color3.fromRGB(255, 255, 255)
	BuyButton.Parent = Card
	
	local BuyCorner = Instance.new("UICorner")
	BuyCorner.CornerRadius = UDim.new(0, 15)
	BuyCorner.Parent = BuyButton
	
	local BuyStroke = Instance.new("UIStroke")
	BuyStroke.Color = Color3.fromRGB(255, 255, 255)
	BuyStroke.Thickness = 4
	BuyStroke.Transparency = 0.4
	BuyStroke.Parent = BuyButton
	
	local BuyGradient = Instance.new("UIGradient")
	BuyGradient.Color = ColorSequence.new({
		ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 200, 80)),
		ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 150, 50))
	})
	BuyGradient.Rotation = 90
	BuyGradient.Parent = BuyButton
	
	-- Button hover
	BuyButton.MouseEnter:Connect(function()
		TweenService:Create(BuyButton, TweenInfo.new(0.2), {
			Size = UDim2.new(1, -25, 0, 50)
		}):Play()
	end)
	
	BuyButton.MouseLeave:Connect(function()
		TweenService:Create(BuyButton, TweenInfo.new(0.2), {
			Size = UDim2.new(1, -30, 0, 45)
		}):Play()
	end)
	
	BuyButton.MouseButton1Click:Connect(function()
		table.insert(cart, {Type = "Cosmetic", Data = itemData})
		updateCartDisplay()
		PurchaseItemEvent:FireServer("Cosmetic", itemData.ID)
	end)
	
	return Card
end

-- FUNCTIONS: Content Management
local function clearContent()
	for _, child in ipairs(ContentFrame:GetChildren()) do
		if child:IsA("Frame") then
			child:Destroy()
		end
	end
end

local function loadVIPPackages()
	clearContent()
	
	for _, packageData in ipairs(ShopData.VIP_PACKAGES) do
		local card = createVIPPackageCard(packageData)
		card.Parent = ContentFrame
	end
end

local function loadCosmetics()
	clearContent()
	
	for _, itemData in ipairs(ShopData.COSMETIC_ITEMS) do
		local card = createCosmeticCard(itemData)
		card.Parent = ContentFrame
	end
end

local function switchTab(tabName)
	currentTab = tabName
	
	if tabName == "VIP" then
		-- Update button states
		VIPTabButton.BackgroundColor3 = Color3.fromRGB(50, 200, 100)
		VIPTabButton.TextColor3 = Color3.fromRGB(255, 255, 255)
		VIPTabButton.BackgroundTransparency = 0
		
		local vipStroke = VIPTabButton:FindFirstChild("UIStroke")
		if vipStroke then
			vipStroke.Transparency = 0
		end
		
		CosmeticsTabButton.BackgroundTransparency = 0.5
		CosmeticsTabButton.TextColor3 = Color3.fromRGB(200, 200, 220)
		
		local cosmeticStroke = CosmeticsTabButton:FindFirstChild("UIStroke")
		if cosmeticStroke then
			cosmeticStroke.Transparency = 0.7
		end
		
		loadVIPPackages()
	elseif tabName == "Cosmetics" then
		-- Update button states
		CosmeticsTabButton.BackgroundColor3 = Color3.fromRGB(220, 100, 255)
		CosmeticsTabButton.TextColor3 = Color3.fromRGB(255, 255, 255)
		CosmeticsTabButton.BackgroundTransparency = 0
		
		local cosmeticStroke = CosmeticsTabButton:FindFirstChild("UIStroke")
		if cosmeticStroke then
			cosmeticStroke.Transparency = 0
		end
		
		VIPTabButton.BackgroundTransparency = 0.5
		VIPTabButton.TextColor3 = Color3.fromRGB(200, 200, 220)
		
		local vipStroke = VIPTabButton:FindFirstChild("UIStroke")
		if vipStroke then
			vipStroke.Transparency = 0.7
		end
		
		loadCosmetics()
	end
end

function updateCartDisplay()
	CartButton.Text = "🛒 " .. #cart
end

local function openShop()
	if isShopOpen then
		return
	end
	
	isShopOpen = true
	tweenIn(MainFrame)
	switchTab("VIP")
end

local function closeShop()
	if not isShopOpen then
		return
	end
	
	isShopOpen = false
	tweenOut(MainFrame)
end

-- EVENTS: Button Connections
CloseButton.MouseButton1Click:Connect(closeShop)

VIPTabButton.MouseButton1Click:Connect(function()
	switchTab("VIP")
end)

CosmeticsTabButton.MouseButton1Click:Connect(function()
	switchTab("Cosmetics")
end)

-- EVENTS: Remote Event Listeners
OpenShopEvent.OnClientEvent:Connect(openShop)

-- EVENTS: Keybind (Press 'T' to toggle shop)
UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then
		return
	end
	
	if input.KeyCode == Enum.KeyCode.T then
		if isShopOpen then
			closeShop()
		else
			openShop()
		end
	end
end)

print("ShopUIController loaded successfully")
