# 🛒 Sistema de Tienda VIP - Guía de Instalación

## 📁 Estructura de Archivos

Coloca cada archivo en su ubicación correspondiente:

```
StarterGui/
└── VIPShopUI.lua                    → Script que crea la interfaz

StarterPlayer/
└── StarterPlayerScripts/
    └── ShopUIController.lua          → Script del cliente (LocalScript)

ServerScriptService/
└── ShopManager.server.lua            → Script del servidor

ReplicatedStorage/
├── Modules/
│   └── ShopData.lua                  → ModuleScript con datos de items
└── Events/
    └── ShopEvents.lua                → Script para crear RemoteEvents
```

## 🔧 Instalación Paso a Paso

### 1. Preparar la Estructura

En Roblox Studio:
1. Asegúrate de tener estas carpetas:
   - `ReplicatedStorage/Modules`
   - `ReplicatedStorage/Events`

### 2. Instalar Scripts Base

**A. ShopEvents.lua**
1. Ve a `ReplicatedStorage > Events`
2. Inserta un **Script** (normal, no LocalScript)
3. Renómbralo a `ShopEvents`
4. Pega el código de `ShopEvents.lua`
5. ▶️ Ejecuta el juego una vez para crear los RemoteEvents

**B. ShopData.lua**
1. Ve a `ReplicatedStorage > Modules`
2. Inserta un **ModuleScript**
3. Renómbralo a `ShopData`
4. Pega el código de `ShopData.lua`

### 3. Instalar UI

**C. VIPShopUI.lua**
1. Ve a `StarterGui`
2. Inserta un **LocalScript**
3. Renómbralo a `VIPShopUI`
4. Pega el código de `VIPShopUI.lua`
5. ▶️ Ejecuta para generar el ScreenGui

**D. ShopUIController.lua**
1. Ve a `StarterPlayer > StarterPlayerScripts`
2. Inserta un **LocalScript**
3. Renómbralo a `ShopUIController`
4. Pega el código de `ShopUIController.lua`

### 4. Instalar Servidor

**E. ShopManager.server.lua**
1. Ve a `ServerScriptService`
2. Inserta un **Script** (normal)
3. Renómbralo a `ShopManager`
4. Pega el código de `ShopManager.server.lua`

## 🎮 Uso y Testing

### Abrir la Tienda

**Método 1: Tecla 'T'**
- Presiona la tecla `T` en el juego para abrir/cerrar la tienda

**Método 2: Desde Comando**
```lua
-- En la consola del servidor:
_G.ShopManagerAPI.OpenShop(game.Players.NombreJugador)
```

### Comandos de Testing

Abre la **Command Bar** en Studio y prueba:

```lua
-- Dar tokens de prueba
_G.ShopManagerAPI.GiveTokens(game.Players.Player1, 1000)

-- Abrir tienda
_G.ShopManagerAPI.OpenShop(game.Players.Player1)

-- Ver inventario
local inv = _G.ShopManagerAPI.GetInventory(game.Players.Player1)
print("Tokens:", inv.Tokens)
print("VIP Packages:", #inv.VIPPackages)
print("Cosmetics:", #inv.Cosmetics)
```

## 🎨 Personalización

### Cambiar Colores de Items

Edita `ShopData.lua`:
```lua
ColorGradient = {
    Start = Color3.fromRGB(255, 100, 200),  -- Color inicial
    Middle = Color3.fromRGB(200, 100, 255), -- Color medio (opcional)
    End = Color3.fromRGB(100, 200, 255)     -- Color final
}
```

### Añadir Nuevo Paquete VIP

En `ShopData.lua`, añade a `VIP_PACKAGES`:
```lua
{
    ID = "vip_mega",
    Name = "VIP Mega",
    Price = 2499,
    BonusTokens = 300,
    TotalTokens = 2799,
    ColorGradient = {
        Start = Color3.fromRGB(255, 0, 255),
        End = Color3.fromRGB(255, 100, 0)
    },
    Icon = "💎",
    SortOrder = 4
}
```

### Añadir Nuevo Cosmético

En `ShopData.lua`, añade a `COSMETIC_ITEMS`:
```lua
{
    ID = "cape_ninja",
    Name = "Capa Ninja",
    Price = 950,
    Rarity = "Épico",
    DropChance = 4.5,
    ColorGradient = {
        Start = Color3.fromRGB(50, 50, 80),
        End = Color3.fromRGB(100, 100, 150)
    },
    Icon = "🥷",
    SortOrder = 7
}
```

## 💰 Integración con Robux

Para conectar con compras reales de Robux, edita `ShopManager.server.lua`:

```lua
-- Reemplaza la función hasEnoughRobux:
local MarketplaceService = game:GetService("MarketplaceService")

local function hasEnoughRobux(player, price)
    local success, info = pcall(function()
        return MarketplaceService:GetProductInfo(PRODUCT_ID)
    end)
    -- Implementa tu lógica de verificación
    return success
end

-- Reemplaza deductRobux con PromptProductPurchase:
local function promptPurchase(player, productId)
    MarketplaceService:PromptProductPurchase(player, productId)
end
```

## 🔐 Guardar Datos (DataStore)

Para persistencia, reemplaza en `ShopManager.server.lua`:

```lua
local DataStoreService = game:GetService("DataStoreService")
local PlayerDataStore = DataStoreService:GetDataStore("PlayerShopData")

-- Al cargar jugador:
local data = PlayerDataStore:GetAsync(player.UserId)

-- Al guardar:
PlayerDataStore:SetAsync(player.UserId, inventory)
```

## ✨ Características Implementadas

✅ UI vibrante con degradados y efectos de brillo
✅ Sistema de pestañas (VIP / Cosméticos)
✅ Tarjetas de items con información completa
✅ Botones con efectos hover y animaciones
✅ Contador de carrito
✅ Sistema de compra funcional (lado servidor)
✅ Gestión de inventario
✅ Atajo de teclado (Tecla T)
✅ Badges de "Popular" y rareza
✅ Responsive a diferentes tamaños

## 🎯 Próximos Pasos Sugeridos

1. **Notificaciones**: Añadir popup de "¡Compra exitosa!"
2. **Animaciones**: Partículas al comprar items legendarios
3. **Preview 3D**: Mostrar modelo 3D del cosmético
4. **Filtros**: Buscar por rareza o precio
5. **Ofertas**: Sistema de descuentos temporales
6. **Historial**: Ver compras anteriores

## 🐛 Troubleshooting

**La tienda no abre:**
- Verifica que ShopEvents.lua se ejecutó correctamente
- Revisa Output para errores
- Comprueba que los RemoteEvents existen en ReplicatedStorage/Events

**Items no se muestran:**
- Verifica que ShopData.lua está en ReplicatedStorage/Modules
- Revisa que el ModuleScript se llama exactamente "ShopData"

**Errores de sintaxis:**
- Asegúrate de copiar todo el código completo
- Verifica que no faltan "end" o cierres de funciones

## 📞 Soporte

Si encuentras problemas, revisa:
1. Output window en Studio
2. Que todos los scripts están en las carpetas correctas
3. Que los nombres coinciden exactamente (mayúsculas/minúsculas)

---

**¡Listo!** Tu sistema de tienda VIP está completo y funcional. 🎉
