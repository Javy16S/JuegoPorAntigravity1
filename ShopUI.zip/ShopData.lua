-- ShopData.lua
-- Configuration data for VIP Shop items
-- Place this in shared/Data/

local ShopData = {}

-- CONFIG: VIP Packages
ShopData.VIP_PACKAGES = {
	{
		ID = "vip_basic",
		Name = "VIP Básico",
		Price = 299,
		BonusTokens = 20,
		TotalTokens = 320,
		ColorGradient = {
			Start = Color3.fromRGB(255, 220, 100),
			Middle = Color3.fromRGB(255, 180, 80),
			End = Color3.fromRGB(255, 100, 50)
		},
		Icon = "👑",
		SortOrder = 1
	},
	{
		ID = "vip_premium",
		Name = "VIP Premium",
		Price = 599,
		BonusTokens = 50,
		TotalTokens = 649,
		ColorGradient = {
			Start = Color3.fromRGB(200, 100, 255),
			Middle = Color3.fromRGB(255, 100, 200),
			End = Color3.fromRGB(255, 80, 100)
		},
		Icon = "⭐",
		Popular = true,
		SortOrder = 2
	},
	{
		ID = "vip_elite",
		Name = "VIP Elite",
		Price = 1299,
		BonusTokens = 150,
		TotalTokens = 1449,
		ColorGradient = {
			Start = Color3.fromRGB(100, 220, 255),
			Middle = Color3.fromRGB(80, 150, 255),
			End = Color3.fromRGB(150, 100, 255)
		},
		Icon = "⚡",
		SortOrder = 3
	}
}

-- CONFIG: Cosmetic Items
ShopData.COSMETIC_ITEMS = {
	{
		ID = "aura_rainbow",
		Name = "Aura Arcoíris",
		Price = 1500,
		Rarity = "Legendario",
		DropChance = 0.675,
		ColorGradient = {
			Start = Color3.fromRGB(255, 100, 200),
			Middle = Color3.fromRGB(200, 100, 255),
			End = Color3.fromRGB(100, 200, 255)
		},
		Icon = "🌈",
		SortOrder = 1
	},
	{
		ID = "wings_celestial",
		Name = "Alas Celestiales",
		Price = 800,
		Rarity = "Épico",
		DropChance = 2.13,
		ColorGradient = {
			Start = Color3.fromRGB(100, 180, 255),
			End = Color3.fromRGB(80, 220, 255)
		},
		Icon = "👼",
		SortOrder = 2
	},
	{
		ID = "crown_golden",
		Name = "Corona Dorada",
		Price = 400,
		Rarity = "Raro",
		DropChance = 12.15,
		ColorGradient = {
			Start = Color3.fromRGB(255, 220, 100),
			End = Color3.fromRGB(255, 160, 50)
		},
		Icon = "👑",
		SortOrder = 3
	},
	{
		ID = "pet_robot",
		Name = "Mascota Robot",
		Price = 150,
		Rarity = "Común",
		DropChance = 32.4,
		ColorGradient = {
			Start = Color3.fromRGB(150, 150, 160),
			End = Color3.fromRGB(100, 100, 120)
		},
		Icon = "🤖",
		SortOrder = 4
	},
	{
		ID = "trail_fire",
		Name = "Trail de Fuego",
		Price = 650,
		Rarity = "Épico",
		DropChance = 6.13,
		ColorGradient = {
			Start = Color3.fromRGB(255, 100, 50),
			End = Color3.fromRGB(255, 160, 80)
		},
		Icon = "🔥",
		SortOrder = 5
	},
	{
		ID = "skin_holographic",
		Name = "Skin Holográfico",
		Price = 1200,
		Rarity = "Legendario",
		DropChance = 0.81,
		ColorGradient = {
			Start = Color3.fromRGB(100, 255, 180),
			Middle = Color3.fromRGB(100, 220, 200),
			End = Color3.fromRGB(100, 200, 255)
		},
		Icon = "✨",
		SortOrder = 6
	}
}

-- CONFIG: Rarity Colors for visual feedback
ShopData.RARITY_COLORS = {
	Legendario = Color3.fromRGB(255, 100, 200),
	Épico = Color3.fromRGB(150, 100, 255),
	Raro = Color3.fromRGB(100, 150, 255),
	Común = Color3.fromRGB(150, 150, 150)
}

-- FUNCTIONS
function ShopData.getVIPPackageByID(id: string)
	for _, package in ipairs(ShopData.VIP_PACKAGES) do
		if package.ID == id then
			return package
		end
	end
	return nil
end

function ShopData.getCosmeticByID(id: string)
	for _, item in ipairs(ShopData.COSMETIC_ITEMS) do
		if item.ID == id then
			return item
		end
	end
	return nil
end

function ShopData.formatPrice(price: number): string
	if price >= 1000 then
		return string.format("%.1fk", price / 1000)
	end
	return tostring(price)
end

return ShopData
