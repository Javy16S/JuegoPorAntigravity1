-- ShopManager.server.lua
-- Server-side shop logic and purchase handling
-- Place this in ServerScriptService/

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

-- Wait for modules
local ShopData = require(ReplicatedStorage:WaitForChild("Modules"):WaitForChild("ShopData"))

-- Wait for RemoteEvents
local Events = ReplicatedStorage:WaitForChild("Events")
local PurchaseItemEvent = Events:WaitForChild("PurchaseItem")
local OpenShopEvent = Events:WaitForChild("OpenShop")

-- CONFIG
local ROBUX_TO_TOKENS_RATIO = 1 -- 1 Robux = 1 Token (adjust as needed)

-- STATE: Player inventories (in production, use DataStore)
local PlayerInventories = {}

-- FUNCTIONS: Inventory Management
local function getPlayerInventory(player)
	if not PlayerInventories[player.UserId] then
		PlayerInventories[player.UserId] = {
			Tokens = 0,
			VIPPackages = {},
			Cosmetics = {}
		}
	end
	return PlayerInventories[player.UserId]
end

local function hasEnoughRobux(player, price)
	-- In production, check actual Robux balance via MarketplaceService
	-- For now, return true for testing
	return true
end

local function deductRobux(player, amount)
	-- In production, use PromptProductPurchase
	-- This is a placeholder
	print("Deducted " .. amount .. " Robux from " .. player.Name)
	return true
end

local function addTokens(player, amount)
	local inventory = getPlayerInventory(player)
	inventory.Tokens = inventory.Tokens + amount
	
	-- Update client UI if needed
	print(player.Name .. " now has " .. inventory.Tokens .. " tokens")
end

local function addCosmeticToInventory(player, cosmeticID)
	local inventory = getPlayerInventory(player)
	
	-- Check if already owned
	for _, ownedID in ipairs(inventory.Cosmetics) do
		if ownedID == cosmeticID then
			return false, "Ya posees este cosmético"
		end
	end
	
	table.insert(inventory.Cosmetics, cosmeticID)
	print(player.Name .. " unlocked cosmetic: " .. cosmeticID)
	return true, "Cosmético desbloqueado"
end

-- FUNCTIONS: Purchase Handlers
local function purchaseVIPPackage(player, packageID)
	local packageData = ShopData.getVIPPackageByID(packageID)
	
	if not packageData then
		warn("Invalid VIP package ID: " .. packageID)
		return false, "Paquete no encontrado"
	end
	
	-- Check if player can afford it
	if not hasEnoughRobux(player, packageData.Price) then
		return false, "Robux insuficientes"
	end
	
	-- Deduct Robux
	local success = deductRobux(player, packageData.Price)
	if not success then
		return false, "Error al procesar pago"
	end
	
	-- Add tokens to inventory
	addTokens(player, packageData.TotalTokens)
	
	-- Record purchase
	local inventory = getPlayerInventory(player)
	table.insert(inventory.VIPPackages, {
		ID = packageID,
		PurchaseTime = os.time()
	})
	
	return true, "Paquete VIP comprado: +" .. packageData.TotalTokens .. " tokens"
end

local function purchaseCosmetic(player, cosmeticID)
	local itemData = ShopData.getCosmeticByID(cosmeticID)
	
	if not itemData then
		warn("Invalid cosmetic ID: " .. cosmeticID)
		return false, "Cosmético no encontrado"
	end
	
	-- Check if player can afford it
	if not hasEnoughRobux(player, itemData.Price) then
		return false, "Robux insuficientes"
	end
	
	-- Deduct Robux
	local success = deductRobux(player, itemData.Price)
	if not success then
		return false, "Error al procesar pago"
	end
	
	-- Add to inventory
	local unlocked, message = addCosmeticToInventory(player, cosmeticID)
	
	if unlocked then
		-- TODO: Apply cosmetic effect to player character
		return true, message
	else
		-- Refund if already owned (shouldn't happen with proper UI)
		return false, message
	end
end

-- EVENTS: Purchase Handler
PurchaseItemEvent.OnServerEvent:Connect(function(player, itemType, itemID)
	if not player or not itemType or not itemID then
		warn("Invalid purchase request")
		return
	end
	
	local success, message
	
	if itemType == "VIP" then
		success, message = purchaseVIPPackage(player, itemID)
	elseif itemType == "Cosmetic" then
		success, message = purchaseCosmetic(player, itemID)
	else
		warn("Unknown item type: " .. tostring(itemType))
		return
	end
	
	-- Send feedback to player
	if success then
		print("✓ Purchase successful: " .. player.Name .. " bought " .. itemID)
		-- TODO: Show success notification on client
	else
		warn("✗ Purchase failed: " .. message)
		-- TODO: Show error notification on client
	end
end)

-- EVENTS: Player Join
Players.PlayerAdded:Connect(function(player)
	-- Initialize inventory
	getPlayerInventory(player)
	
	-- Wait for character
	player.CharacterAdded:Connect(function(character)
		-- Apply owned cosmetics to character
		local inventory = getPlayerInventory(player)
		for _, cosmeticID in ipairs(inventory.Cosmetics) do
			-- TODO: Apply cosmetic effects
			print("Applying cosmetic " .. cosmeticID .. " to " .. player.Name)
		end
	end)
end)

-- EVENTS: Player Leave (save data)
Players.PlayerRemoving:Connect(function(player)
	-- In production, save to DataStore
	local inventory = getPlayerInventory(player)
	print("Saving inventory for " .. player.Name .. ": " .. inventory.Tokens .. " tokens")
	
	-- Clear from memory
	PlayerInventories[player.UserId] = nil
end)

-- FUNCTIONS: Admin Commands (for testing)
local function giveTokens(player, amount)
	addTokens(player, amount)
end

local function openShopForPlayer(player)
	OpenShopEvent:FireClient(player)
end

-- Export for testing
_G.ShopManagerAPI = {
	GiveTokens = giveTokens,
	OpenShop = openShopForPlayer,
	GetInventory = getPlayerInventory
}

print("ShopManager initialized successfully")
